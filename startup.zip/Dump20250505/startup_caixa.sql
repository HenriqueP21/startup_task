CREATE DATABASE  IF NOT EXISTS `startup` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `startup`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: startup
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `caixa`
--

DROP TABLE IF EXISTS `caixa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `caixa` (
  `id` int NOT NULL AUTO_INCREMENT,
  `descricao` varchar(100) NOT NULL,
  `saldo_inicial` decimal(12,2) NOT NULL,
  `data_abertura` date NOT NULL,
  `data_fechamento` date DEFAULT NULL,
  `status` enum('aberto','fechado') DEFAULT 'aberto',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=101 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `caixa`
--

LOCK TABLES `caixa` WRITE;
/*!40000 ALTER TABLE `caixa` DISABLE KEYS */;
INSERT INTO `caixa` VALUES (1,'mauris',1.88,'2025-05-05','2024-04-24','aberto'),(2,'semper',4.38,'2025-08-14','2024-11-04','aberto'),(3,'morbi',0.01,'2025-12-21','2024-09-25','aberto'),(4,'cursus',9.24,'2025-06-04','2024-09-12','aberto'),(5,'eleifend',7.65,'2025-11-14','2025-02-25','fechado'),(6,'a',3.47,'2025-10-18','2024-10-25','aberto'),(7,'et',2.63,'2025-11-10','2024-11-19','aberto'),(8,'vulputate',2.12,'2026-01-27','2025-02-02','fechado'),(9,'varius',1.77,'2025-04-21','2024-06-18','fechado'),(10,'ac',4.53,'2025-11-13','2024-09-19','aberto'),(11,'duis',0.24,'2025-06-20','2024-04-14','aberto'),(12,'rhoncus',1.17,'2025-10-02','2024-08-16','fechado'),(13,'a',8.96,'2025-05-30','2024-09-25','aberto'),(14,'erat',1.45,'2025-06-14','2024-07-27','fechado'),(15,'pellentesque',6.96,'2025-12-07','2025-04-13','aberto'),(16,'cubilia',6.10,'2025-06-30','2025-01-17','aberto'),(17,'amet',5.28,'2025-11-29','2024-07-21','fechado'),(18,'blandit',7.30,'2026-01-10','2025-04-03','fechado'),(19,'potenti',3.21,'2026-01-15','2024-10-04','aberto'),(20,'laoreet',5.15,'2025-06-07','2024-05-30','fechado'),(21,'at',1.94,'2025-06-29','2025-03-14','aberto'),(22,'vitae',1.48,'2025-05-04','2024-05-07','fechado'),(23,'convallis',9.33,'2025-07-16','2024-07-09','aberto'),(24,'diam',4.45,'2025-08-25','2025-03-11','fechado'),(25,'pretium',9.14,'2026-01-08','2025-04-08','aberto'),(26,'non',6.10,'2025-07-18','2024-08-10','aberto'),(27,'lorem',3.01,'2025-05-21','2025-03-20','aberto'),(28,'integer',7.87,'2025-06-05','2025-03-29','fechado'),(29,'nec',6.93,'2025-10-06','2024-08-29','aberto'),(30,'nisl',8.82,'2026-01-18','2024-09-02','fechado'),(31,'pulvinar',7.76,'2025-11-11','2024-11-23','aberto'),(32,'magna',2.69,'2025-12-08','2025-04-29','aberto'),(33,'eget',9.60,'2025-07-25','2025-05-16','fechado'),(34,'mi',4.77,'2025-09-09','2024-06-14','fechado'),(35,'etiam',8.85,'2025-12-15','2024-11-08','fechado'),(36,'vehicula',4.82,'2025-11-05','2024-06-21','fechado'),(37,'dictum',7.92,'2025-06-12','2025-01-25','aberto'),(38,'a',4.21,'2025-12-19','2025-05-05','fechado'),(39,'urna',2.37,'2025-07-03','2024-07-28','aberto'),(40,'nec',2.15,'2025-08-18','2025-04-05','aberto'),(41,'ligula',3.61,'2025-12-26','2025-01-10','fechado'),(42,'adipiscing',3.68,'2025-10-13','2024-05-24','fechado'),(43,'nunc',9.44,'2025-12-30','2024-09-20','aberto'),(44,'faucibus',9.51,'2025-11-07','2025-03-18','aberto'),(45,'sagittis',4.28,'2025-10-01','2024-11-10','aberto'),(46,'vitae',0.79,'2025-05-16','2024-10-29','aberto'),(47,'justo',9.32,'2025-09-21','2024-07-01','fechado'),(48,'ac',9.87,'2025-07-05','2024-06-06','fechado'),(49,'nibh',3.98,'2025-09-13','2025-03-23','aberto'),(50,'dui',6.47,'2025-10-17','2024-12-15','fechado'),(51,'ante',1.35,'2025-07-29','2024-10-15','aberto'),(52,'mattis',9.56,'2025-09-22','2024-07-13','fechado'),(53,'turpis',9.42,'2025-06-22','2024-09-17','fechado'),(54,'dictum',2.92,'2025-08-22','2024-05-01','fechado'),(55,'mollis',0.61,'2025-12-17','2025-04-26','fechado'),(56,'massa',4.53,'2025-07-30','2024-11-11','fechado'),(57,'integer',1.16,'2025-11-23','2025-01-23','aberto'),(58,'enim',3.59,'2025-12-09','2025-02-28','fechado'),(59,'tellus',8.63,'2025-09-01','2024-10-21','aberto'),(60,'orci',4.80,'2025-10-19','2024-12-30','fechado'),(61,'tellus',2.96,'2025-05-09','2025-02-15','aberto'),(62,'velit',5.83,'2025-09-23','2025-04-23','fechado'),(63,'donec',8.28,'2025-07-22','2024-08-12','fechado'),(64,'vel',6.19,'2025-11-04','2024-07-06','fechado'),(65,'donec',5.13,'2025-12-25','2024-11-18','aberto'),(66,'ut',6.94,'2025-07-27','2025-02-22','aberto'),(67,'interdum',9.92,'2025-10-11','2024-08-07','aberto'),(68,'est',8.70,'2025-11-19','2024-09-06','fechado'),(69,'ut',6.49,'2025-08-03','2025-02-03','fechado'),(70,'non',5.57,'2025-12-23','2025-03-20','fechado'),(71,'lacinia',2.84,'2025-08-21','2025-04-01','aberto'),(72,'proin',1.24,'2025-09-03','2025-07-15','fechado'),(73,'sit',0.83,'2025-07-17','2024-05-28','aberto'),(74,'mauris',4.25,'2025-12-05','2024-09-23','fechado'),(75,'urna',3.99,'2025-08-05','2024-06-02','fechado'),(76,'suspendisse',5.81,'2025-12-21','2025-04-18','fechado'),(77,'eleifend',2.60,'2025-11-06','2024-07-20','aberto'),(78,'neque',9.97,'2025-12-12','2025-01-15','fechado'),(79,'pellentesque',5.02,'2025-10-04','2025-05-09','aberto'),(80,'ligula',6.45,'2025-09-19','2025-06-30','aberto'),(81,'sit',2.49,'2025-07-02','2025-02-13','fechado'),(82,'at',1.83,'2025-11-29','2025-05-02','aberto'),(83,'vel',8.91,'2025-06-14','2025-03-29','fechado'),(84,'lacinia',7.07,'2025-07-01','2024-12-18','aberto'),(85,'eleifend',2.68,'2025-08-17','2024-05-23','fechado'),(86,'felis',0.95,'2025-10-06','2025-04-07','fechado'),(87,'dolor',8.31,'2025-12-14','2025-02-25','aberto'),(88,'magna',6.18,'2025-11-14','2025-01-19','fechado'),(89,'nullam',2.77,'2025-07-19','2025-06-07','aberto'),(90,'dui',3.57,'2025-10-20','2024-09-29','fechado'),(91,'ut',4.13,'2025-09-28','2025-04-11','aberto'),(92,'nulla',6.83,'2025-07-23','2025-02-16','aberto'),(93,'pretium',9.56,'2025-11-25','2025-03-04','aberto'),(94,'nullam',8.29,'2025-08-04','2024-07-09','aberto'),(95,'neque',1.72,'2025-10-15','2025-01-02','aberto'),(96,'aliquam',0.80,'2025-09-02','2025-07-22','fechado'),(97,'est',3.96,'2025-10-14','2025-03-31','fechado'),(98,'sed',4.01,'2025-11-10','2025-04-13','fechado'),(99,'risus',7.58,'2025-12-03','2025-02-01','aberto'),(100,'lectus',5.91,'2025-06-03','2024-10-03','fechado');
/*!40000 ALTER TABLE `caixa` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-05 17:58:42
