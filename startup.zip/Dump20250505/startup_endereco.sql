CREATE DATABASE  IF NOT EXISTS `startup` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `startup`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: startup
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `endereco`
--

DROP TABLE IF EXISTS `endereco`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `endereco` (
  `id` int NOT NULL AUTO_INCREMENT,
  `logradouro` varchar(100) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `complemento` varchar(50) DEFAULT NULL,
  `bairro` varchar(50) NOT NULL,
  `cidade` varchar(50) NOT NULL,
  `estado` char(2) NOT NULL,
  `cep` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco`
--

LOCK TABLES `endereco` WRITE;
/*!40000 ALTER TABLE `endereco` DISABLE KEYS */;
INSERT INTO `endereco` VALUES (1,'Rua dos Três Irmãos','123','Apt 202','Jardim Paulista','São Paulo','SP','01015-020'),(2,'Avenida Paulista','179','Suite 85','Bela Vista','São Paulo','SP','01311-000'),(3,'Rua dos Três Irmãos','37','15th Floor','Jardim Paulista','São Paulo','SP','01015-020'),(4,'Rua Augusta','3','Suite 40','Consolação','São Paulo','SP','01305-000'),(5,'Rua dos Três Irmãos','847','Apt 1454','Jardim Paulista','São Paulo','SP','01015-020'),(6,'Rua Fagundes Filho','9','PO Box 70365','Vila Mariana','São Paulo','SP','04103-000'),(7,'Rua Augusta','53486','Suite 1','Jardim Paulista','São Paulo','SP','01305-000'),(8,'Avenida Brigadeiro Faria Lima','957','13th Floor','Jardim Paulistano','São Paulo','SP','01452-000'),(9,'Rua dos Três Irmãos','31','Suite 52','Bela Vista','São Paulo','SP','01015-020'),(10,'Rua dos Três Irmãos','7','Room 339','Jardim Paulista','São Paulo','SP','01015-020'),(11,'Rua dos Três Irmãos','81308','Room 172','Consolação','São Paulo','SP','01305-000'),(12,'Rua dos Três Irmãos','1','Room 1103','Vila Mariana','São Paulo','SP','04103-000'),(13,'Avenida Faria Lima','4','Suite 42','Itaim Bibi','São Paulo','SP','04538-132'),(14,'Rua dos Três Irmãos','16467','Room 295','Bela Vista','São Paulo','SP','01015-020'),(15,'Avenida Brigadeiro Faria Lima','78178','Suite 52','Itaim Bibi','São Paulo','SP','04538-132'),(16,'Avenida 9 de Julho','9','Apt 1887','Vila Olímpia','São Paulo','SP','04568-000'),(17,'Rua dos Três Irmãos','8','Apt 930','Pinheiros','São Paulo','SP','05422-001'),(18,'Rua da Consolação','0832','Room 1004','Consolação','São Paulo','SP','01302-000'),(19,'Avenida Paulista','274','PO Box 25291','Bela Vista','São Paulo','SP','01311-000'),(20,'Rua dos Três Irmãos','8160','17th Floor','Itaim Bibi','São Paulo','SP','04538-132'),(21,'Avenida Faria Lima','181','Room 1796','Itaim Bibi','São Paulo','SP','04538-132'),(22,'Rua Augusta','2579','6th Floor','Consolação','São Paulo','SP','01305-000'),(23,'Rua dos Três Irmãos','43','18th Floor','Vila Mariana','São Paulo','SP','04103-000'),(24,'Rua Augusta','9','Suite 99','Bela Vista','São Paulo','SP','01305-000'),(25,'Avenida Faria Lima','7','16th Floor','Itaim Bibi','São Paulo','SP','04538-132'),(26,'Rua dos Três Irmãos','476','Apt 1468','Jardim Paulista','São Paulo','SP','01015-020'),(27,'Rua Augusta','164','PO Box 3432','Bela Vista','São Paulo','SP','01305-000'),(28,'Avenida Brigadeiro Faria Lima','83602','PO Box 86553','Vila Olímpia','São Paulo','SP','04568-000'),(29,'Rua dos Três Irmãos','79','PO Box 33419','Jardim Paulista','São Paulo','SP','01015-020'),(30,'Rua da Consolação','13','PO Box 29333','Consolação','São Paulo','SP','01302-000'),(31,'Rua dos Três Irmãos','23388','Apt 1578','Vila Mariana','São Paulo','SP','04103-000'),(32,'Avenida Faria Lima','924','8th Floor','Itaim Bibi','São Paulo','SP','04538-132'),(33,'Rua Augusta','85454','5th Floor','Consolação','São Paulo','SP','01305-000'),(34,'Avenida 9 de Julho','97','Room 507','Vila Olímpia','São Paulo','SP','04568-000'),(35,'Rua das Flores','9245','6º Andar','Vila Progredior','São Paulo','SP','01001-000'),(36,'Avenida Paulista','3608','2º Andar','Bela Vista','São Paulo','SP','01310-100'),(37,'Rua Augusta','7','Suite 28','Consolação','São Paulo','SP','01305-000'),(38,'Rua dos Três Irmãos','6','16º Andar','Vila Progredior','São Paulo','SP','02502-000'),(39,'Rua da Consolação','1486','12º Andar','Bela Vista','São Paulo','SP','01301-000'),(40,'Rua dos Três Irmãos','3791','Sala 1174','Bela Vista','São Paulo','SP','01029-000'),(41,'Rua Maria Antônia','691','Suite 26','Consolação','São Paulo','SP','01222-000'),(42,'Rua do Triunfo','5','PO Box 39337','Vila Progredior','São Paulo','SP','04004-000'),(43,'Avenida Brigadeiro Luís Antônio','191','Suite 20','Vila Progredior','São Paulo','SP','01007-000'),(44,'Rua da Consolação','69054','PO Box 73348','Bela Vista','São Paulo','SP','01310-100'),(45,'Rua dos Três Irmãos','11282','Suite 14','Consolação','São Paulo','SP','01305-000'),(46,'Rua 24 de Maio','461','12º Andar','Bela Vista','São Paulo','SP','01002-000'),(47,'Avenida Paulista','5','7º Andar','Vila Progredior','São Paulo','SP','01311-000'),(48,'Rua dos Três Irmãos','800','Suite 24','Vila Progredior','São Paulo','SP','04008-000'),(49,'Rua Augusta','71561','PO Box 62552','Bela Vista','São Paulo','SP','01305-000'),(50,'Rua Maria Antônia','69','Apt 368','Vila Progredior','São Paulo','SP','01029-000'),(51,'Rua dos Três Irmãos','08','Apt 1275','Consolação','São Paulo','SP','01222-000'),(52,'Avenida Brigadeiro Luís Antônio','0','PO Box 54815','Vila Progredior','São Paulo','SP','04004-000'),(53,'Avenida Paulista','7','Apt 1846','Bela Vista','São Paulo','SP','01001-000'),(54,'Rua 24 de Maio','90292','Apt 1477','Consolação','São Paulo','SP','01002-000'),(55,'Rua da Consolação','8','PO Box 25570','Bela Vista','São Paulo','SP','01310-100'),(56,'Avenida Brigadeiro Luís Antônio','28','Suite 38','Vila Progredior','São Paulo','SP','01007-000'),(57,'Rua das Figueiras','174','Bloco A','Vila Progredior','São Paulo','SP','03375-020'),(58,'Avenida Paulista','500','Sala 22','Bela Vista','São Paulo','SP','01310-000'),(59,'Rua dos Três Irmãos','252','Apartamento 302','Vila Progredior','São Paulo','SP','02220-010'),(60,'Rua da Consolação','1056','Loja 4','Consolação','São Paulo','SP','01301-000'),(61,'Rua da Liberdade','132','Apto 55','Liberdade','São Paulo','SP','01503-000'),(62,'Avenida 9 de Julho','214','Andar 5','Cerqueira César','São Paulo','SP','01407-000'),(63,'Rua da República','758','Café 1','República','São Paulo','SP','01300-000'),(64,'Avenida dos Bandeirantes','830','Piso 1','Vila Progredior','São Paulo','SP','04607-005'),(65,'Rua dos Três Irmãos','525','Bloco C','Vila Clementino','São Paulo','SP','04030-000'),(66,'Rua das Palmeiras','200','Piso Térreo','Jardim Paulista','São Paulo','SP','01417-000'),(67,'Rua do Paraiso','389','Apto 98','Paraíso','São Paulo','SP','04103-000'),(68,'Avenida Engenheiro Caetano Álvares','1580','Loja 3','Mandaqui','São Paulo','SP','02244-000'),(69,'Rua da Mooca','3500','Café 6','Mooca','São Paulo','SP','03103-000'),(70,'Rua dos Três Irmãos','78','Casa 5','Vila Progredior','São Paulo','SP','02220-030'),(71,'Rua da Consolação','52','Apto 1518','Paulista','São Paulo','SP','01201-100'),(72,'Avenida Brigadeiro Faria Lima','722','Sala 58','Pinheiros','São Paulo','SP','05426-100'),(73,'Rua dos Três Irmãos','82353','Suíte 84','Bela Vista','São Paulo','SP','01320-000'),(74,'Rua Augusta','1','Sala 371','Jardins','São Paulo','SP','01412-000'),(75,'Rua do Rio','328','9º Andar','Vila Progredior','São Paulo','SP','04551-000'),(76,'Avenida Paulista','5354','Sala 1927','Bela Vista','São Paulo','SP','01311-000'),(77,'Rua dos Três Irmãos','01','Suíte 55','Vila Progredior','São Paulo','SP','04551-000'),(78,'Rua São Bento','8','Apto 1326','Sé','São Paulo','SP','01011-100'),(79,'Rua dos Três Irmãos','78','PO Box 38735','Bela Vista','São Paulo','SP','01320-000'),(80,'Avenida Paulista','38916','Sala 322','Cerqueira César','São Paulo','SP','01311-000'),(81,'Rua dos Três Irmãos','2','Sala 1617','Vila Progredior','São Paulo','SP','04551-000'),(82,'Rua dos Três Irmãos','14','Sala 1206','Vila Progredior','São Paulo','SP','04551-000'),(83,'Avenida Faria Lima','7','PO Box 16134','Pinheiros','São Paulo','SP','05426-100'),(84,'Rua Augusta','25','15º Andar','Bela Vista','São Paulo','SP','01412-000'),(85,'Rua dos Três Irmãos','372','Suíte 89','Vila Progredior','São Paulo','SP','04551-000'),(86,'Rua dos Três Irmãos','1057','Sala 203','Vila Progredior','São Paulo','SP','04551-000'),(87,'Rua dos Três Irmãos','896','Apto 1391','Vila Progredior','São Paulo','SP','04551-000'),(88,'Rua São Bento','97','PO Box 18170','Sé','São Paulo','SP','01011-100'),(89,'Rua dos Três Irmãos','8294','Sala 1769','Vila Progredior','São Paulo','SP','04551-000'),(90,'Rua dos Três Irmãos','86','3º Andar','Vila Progredior','São Paulo','SP','04551-000'),(91,'Rua dos Três Irmãos','6','Sala 102','Vila Progredior','São Paulo','SP','04551-000'),(92,'Rua dos Três Irmãos','223','16º Andar','Vila Progredior','São Paulo','SP','04551-000'),(93,'Avenida Faria Lima','7944','Apto 1203','Pinheiros','São Paulo','SP','05426-100'),(94,'Rua dos Três Irmãos','86329','PO Box 69756','Vila Progredior','São Paulo','SP','04551-000'),(95,'Rua dos Três Irmãos','22','8º Andar','Vila Progredior','São Paulo','SP','04551-000'),(96,'Rua dos Três Irmãos','35703','Apto 670','Vila Progredior','São Paulo','SP','04551-000'),(97,'Rua dos Três Irmãos','0','Sala 62','Vila Progredior','São Paulo','SP','04551-000'),(98,'Rua dos Três Irmãos','16','Sala 1561','Vila Progredior','São Paulo','SP','04551-000'),(99,'Rua dos Três Irmãos','60','PO Box 84586','Vila Progredior','São Paulo','SP','04551-000');
/*!40000 ALTER TABLE `endereco` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-05-05 17:58:41
