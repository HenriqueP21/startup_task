/* use startup */



/* select * from banco */